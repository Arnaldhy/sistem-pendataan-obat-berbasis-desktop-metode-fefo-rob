
package aplikasi.pendataan.obat;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class dashboard extends JFrame {

    private final Color ungu = new Color(124, 92, 201);
    private final Color unguGelap = new Color(81, 55, 150);
    private final Color latar = new Color(246, 247, 252);
    private final Color teks = new Color(43, 45, 66);
    private final Color abu = new Color(133, 139, 158);
    private final Color garis = new Color(235, 236, 244);

    private JPanel konten;
    private JLabel judulHalaman;
    private JLabel labelTanggal;
    private JButton menuAktif;
    private JTable tabelObat;

    public dashboard() {
        setTitle("HAI OBAT | Sistem Pendataan Obat");
        setSize(1250, 780);
        setMinimumSize(new Dimension(1050, 650));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(latar);

        root.add(buatSidebar(), BorderLayout.WEST);
        root.add(buatAreaUtama(), BorderLayout.CENTER);

        setContentPane(root);
        tampilDashboard();
    }

    private JPanel buatSidebar() {
        JPanel sidebar = new JPanel();
        sidebar.setPreferredSize(new Dimension(245, 0));
        sidebar.setBackground(Color.WHITE);
        sidebar.setLayout(new BorderLayout());
        sidebar.setBorder(new MatteBorder(0, 0, 0, 1, garis));

        JPanel atas = new JPanel();
        atas.setOpaque(false);
        atas.setLayout(new BoxLayout(atas, BoxLayout.Y_AXIS));
        atas.setBorder(new EmptyBorder(28, 20, 15, 20));

        JPanel logo = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        logo.setOpaque(false);
        logo.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel simbol = new JLabel("✚");
        simbol.setFont(new Font("SansSerif", Font.BOLD, 27));
        simbol.setForeground(ungu);

        JLabel nama = new JLabel("HAI OBAT");
        nama.setFont(new Font("SansSerif", Font.BOLD, 25));
        nama.setForeground(unguGelap);

        logo.add(simbol);
        logo.add(nama);

        JLabel sub = new JLabel("Sistem Pendataan Obat");
        sub.setFont(new Font("SansSerif", Font.PLAIN, 12));
        sub.setForeground(abu);
        sub.setBorder(new EmptyBorder(5, 3, 24, 0));
        sub.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel menuLabel = new JLabel("MENU UTAMA");
        menuLabel.setFont(new Font("SansSerif", Font.BOLD, 10));
        menuLabel.setForeground(abu);
        menuLabel.setBorder(new EmptyBorder(0, 8, 12, 0));
        menuLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        atas.add(logo);
        atas.add(sub);
        atas.add(menuLabel);

        JPanel daftarMenu = new JPanel();
        daftarMenu.setOpaque(false);
        daftarMenu.setLayout(new BoxLayout(daftarMenu, BoxLayout.Y_AXIS));
        daftarMenu.setBorder(new EmptyBorder(0, 12, 10, 12));

        tambahMenu(daftarMenu, "▦", "Dashboard");
        tambahMenu(daftarMenu, "▤", "Data Obat");
        tambahMenu(daftarMenu, "↓", "Stok Masuk");
        tambahMenu(daftarMenu, "↑", "Stok Keluar");
        tambahMenu(daftarMenu, "!", "Peringatan ROB & FEFO");
        tambahMenu(daftarMenu, "▥", "Laporan");

        JPanel bawah = new JPanel();
        bawah.setOpaque(false);
        bawah.setLayout(new BoxLayout(bawah, BoxLayout.Y_AXIS));
        bawah.setBorder(new EmptyBorder(12, 15, 20, 15));

        JSeparator pemisah = new JSeparator();
        pemisah.setForeground(garis);
        pemisah.setMaximumSize(new Dimension(Integer.MAX_VALUE, 1));

        JLabel info = new JLabel(
            "<html><div style='text-align:center;'>"
            + "HAI OBAT<br>Inventory System v1.0"
            + "</div></html>"
        );
        info.setFont(new Font("SansSerif", Font.PLAIN, 11));
        info.setForeground(abu);
        info.setAlignmentX(Component.CENTER_ALIGNMENT);
        info.setBorder(new EmptyBorder(14, 0, 15, 0));

        JButton keluar = new JButton("⇥   Keluar");
        keluar.setFont(new Font("SansSerif", Font.BOLD, 13));
        keluar.setForeground(new Color(210, 72, 91));
        keluar.setBackground(new Color(255, 241, 244));
        keluar.setFocusPainted(false);
        keluar.setBorderPainted(false);
        keluar.setCursor(new Cursor(Cursor.HAND_CURSOR));
        keluar.setMaximumSize(new Dimension(Integer.MAX_VALUE, 43));
        keluar.setAlignmentX(Component.LEFT_ALIGNMENT);

        keluar.addActionListener(e -> {
            int pilih = JOptionPane.showConfirmDialog(
                this,
                "Apakah kamu yakin ingin keluar?",
                "Konfirmasi Keluar",
                JOptionPane.YES_NO_OPTION
            );

            if (pilih == JOptionPane.YES_OPTION) {
                new login().setVisible(true);
                dispose();
            }
        });

        bawah.add(pemisah);
        bawah.add(info);
        bawah.add(keluar);

        sidebar.add(atas, BorderLayout.NORTH);
        sidebar.add(daftarMenu, BorderLayout.CENTER);
        sidebar.add(bawah, BorderLayout.SOUTH);

        return sidebar;
    }

    private void tambahMenu(
        JPanel panel, String ikon, String nama
    ) {
        JButton tombol = new JButton(ikon + "    " + nama);
        tombol.setFont(new Font("SansSerif", Font.PLAIN, 13));
        tombol.setHorizontalAlignment(SwingConstants.LEFT);
        tombol.setMaximumSize(new Dimension(Integer.MAX_VALUE, 45));
        tombol.setPreferredSize(new Dimension(205, 45));
        tombol.setFocusPainted(false);
        tombol.setBorderPainted(false);
        tombol.setOpaque(true);
        tombol.setBorder(new EmptyBorder(0, 14, 0, 8));
        tombol.setCursor(new Cursor(Cursor.HAND_CURSOR));

        aturGayaMenu(tombol, false);

        tombol.addActionListener(e -> {
            if (menuAktif != null) {
                aturGayaMenu(menuAktif, false);
            }

            menuAktif = tombol;
            aturGayaMenu(tombol, true);

            switch (nama) {
                case "Dashboard":
                    tampilDashboard();
                    break;
                case "Data Obat":
                    tampilHalamanKosong(
                        "Data Obat",
                        "Kelola data obat, kode, kategori, dan satuan."
                    );
                    break;
                case "Stok Masuk":
                    tampilHalamanKosong(
                        "Stok Masuk",
                        "Catat penerimaan obat dan batch baru."
                    );
                    break;
                case "Stok Keluar":
                    tampilHalamanKosong(
                        "Stok Keluar",
                        "Catat pengeluaran obat dengan prioritas FEFO."
                    );
                    break;
                case "Peringatan ROB & FEFO":
                    tampilHalamanKosong(
                        "Peringatan ROB & FEFO",
                        "Pantau stok minimum dan tanggal kedaluwarsa."
                    );
                    break;
                case "Laporan":
                    tampilHalamanKosong(
                        "Laporan",
                        "Ringkasan persediaan dan riwayat transaksi."
                    );
                    break;
            }
        });

        panel.add(tombol);
        panel.add(Box.createVerticalStrut(5));

        if (nama.equals("Dashboard")) {
            menuAktif = tombol;
            aturGayaMenu(tombol, true);
        }
    }

    private void aturGayaMenu(JButton tombol, boolean aktif) {
        tombol.setBackground(
            aktif ? new Color(241, 236, 255) : Color.WHITE
        );
        tombol.setForeground(aktif ? ungu : new Color(88, 91, 111));
        tombol.setFont(new Font(
            "SansSerif",
            aktif ? Font.BOLD : Font.PLAIN,
            13
        ));
    }

    private JPanel buatAreaUtama() {
        JPanel area = new JPanel(new BorderLayout());
        area.setBackground(latar);

        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(Color.WHITE);
        header.setBorder(new CompoundBorder(
            new MatteBorder(0, 0, 1, 0, garis),
            new EmptyBorder(19, 27, 19, 27)
        ));

        judulHalaman = new JLabel("Dashboard");
        judulHalaman.setFont(new Font("SansSerif", Font.BOLD, 23));
        judulHalaman.setForeground(teks);

        JPanel profil = new JPanel();
        profil.setOpaque(false);
        profil.setLayout(new BoxLayout(profil, BoxLayout.Y_AXIS));

        JLabel namaAdmin = new JLabel("Administrator");
        namaAdmin.setFont(new Font("SansSerif", Font.BOLD, 12));
        namaAdmin.setForeground(teks);
        namaAdmin.setAlignmentX(Component.RIGHT_ALIGNMENT);

        JLabel status = new JLabel("●  Online");
        status.setFont(new Font("SansSerif", Font.PLAIN, 11));
        status.setForeground(new Color(44, 165, 112));
        status.setAlignmentX(Component.RIGHT_ALIGNMENT);

        profil.add(namaAdmin);
        profil.add(Box.createVerticalStrut(4));
        profil.add(status);

        header.add(judulHalaman, BorderLayout.WEST);
        header.add(profil, BorderLayout.EAST);

        konten = new JPanel(new BorderLayout());
        konten.setBackground(latar);
        konten.setBorder(new EmptyBorder(25, 27, 25, 27));

        area.add(header, BorderLayout.NORTH);
        area.add(konten, BorderLayout.CENTER);

        return area;
    }

    private void tampilDashboard() {
        judulHalaman.setText("Dashboard");
        konten.removeAll();
        konten.setLayout(new BorderLayout(0, 20));

        JPanel isi = new JPanel();
        isi.setOpaque(false);
        isi.setLayout(new BoxLayout(isi, BoxLayout.Y_AXIS));

        JPanel sambutan = new JPanel(new BorderLayout());
        sambutan.setOpaque(false);
        sambutan.setAlignmentX(Component.LEFT_ALIGNMENT);
        sambutan.setMaximumSize(
            new Dimension(Integer.MAX_VALUE, 76)
        );

        JPanel teksSambutan = new JPanel();
        teksSambutan.setOpaque(false);
        teksSambutan.setLayout(new BoxLayout(
            teksSambutan, BoxLayout.Y_AXIS
        ));

        JLabel sapaan = new JLabel("Selamat datang di HAI OBAT!");
        sapaan.setFont(new Font("SansSerif", Font.BOLD, 24));
        sapaan.setForeground(teks);

        JLabel deskripsi = new JLabel(
            "Pantau persediaan dan kedaluwarsa obat dalam satu tempat."
        );
        deskripsi.setFont(new Font("SansSerif", Font.PLAIN, 13));
        deskripsi.setForeground(abu);

        teksSambutan.add(sapaan);
        teksSambutan.add(Box.createVerticalStrut(7));
        teksSambutan.add(deskripsi);

        labelTanggal = new JLabel(
            new SimpleDateFormat("dd MMMM yyyy").format(new Date())
        );
        labelTanggal.setFont(new Font("SansSerif", Font.BOLD, 12));
        labelTanggal.setForeground(unguGelap);
        labelTanggal.setBorder(new CompoundBorder(
            new LineBorder(new Color(228, 220, 250)),
            new EmptyBorder(10, 13, 10, 13)
        ));
        labelTanggal.setOpaque(true);
        labelTanggal.setBackground(Color.WHITE);

        sambutan.add(teksSambutan, BorderLayout.WEST);
        sambutan.add(labelTanggal, BorderLayout.EAST);

        isi.add(sambutan);
        isi.add(Box.createVerticalStrut(22));

        JPanel statistik = new JPanel(new GridLayout(1, 4, 15, 0));
        statistik.setOpaque(false);
        statistik.setAlignmentX(Component.LEFT_ALIGNMENT);
        statistik.setMaximumSize(
            new Dimension(Integer.MAX_VALUE, 135)
        );

        statistik.add(buatKartu(
            "TOTAL JENIS OBAT", "0", "Obat terdaftar", "✚",
            ungu, new Color(243, 238, 255)
        ));

        statistik.add(buatKartu(
            "TOTAL STOK", "0", "Seluruh unit tersedia", "▤",
            new Color(42, 146, 203), new Color(232, 246, 255)
        ));

        statistik.add(buatKartu(
            "STOK MENIPIS", "0", "Perlu pemeriksaan ROB", "!",
            new Color(222, 153, 45), new Color(255, 247, 226)
        ));

        statistik.add(buatKartu(
            "DEKAT KEDALUWARSA", "0", "Prioritas FEFO", "◷",
            new Color(218, 91, 113), new Color(255, 237, 241)
        ));

        isi.add(statistik);
        isi.add(Box.createVerticalStrut(22));

        JPanel tengah = new JPanel(new GridLayout(1, 2, 18, 0));
        tengah.setOpaque(false);
        tengah.setAlignmentX(Component.LEFT_ALIGNMENT);
        tengah.setMaximumSize(
            new Dimension(Integer.MAX_VALUE, 330)
        );

        tengah.add(buatPanelTabel());
        tengah.add(buatPanelPeringatan());

        isi.add(tengah);
        isi.add(Box.createVerticalStrut(20));

        JPanel catatan = panelPutih();
        catatan.setLayout(new BorderLayout(12, 0));
        catatan.setBorder(new CompoundBorder(
            new LineBorder(garis),
            new EmptyBorder(16, 18, 16, 18)
        ));
        catatan.setAlignmentX(Component.LEFT_ALIGNMENT);
        catatan.setMaximumSize(
            new Dimension(Integer.MAX_VALUE, 90)
        );

        JLabel ikonInfo = new JLabel("i");
        ikonInfo.setFont(new Font("SansSerif", Font.BOLD, 18));
        ikonInfo.setForeground(ungu);
        ikonInfo.setHorizontalAlignment(SwingConstants.CENTER);
        ikonInfo.setPreferredSize(new Dimension(35, 35));
        ikonInfo.setOpaque(true);
        ikonInfo.setBackground(new Color(243, 238, 255));

        JPanel infoTeks = new JPanel();
        infoTeks.setOpaque(false);
        infoTeks.setLayout(new BoxLayout(
            infoTeks, BoxLayout.Y_AXIS
        ));

        JLabel judulInfo = new JLabel("Informasi sistem");
        judulInfo.setFont(new Font("SansSerif", Font.BOLD, 13));
        judulInfo.setForeground(teks);

        JLabel isiInfo = new JLabel(
            "Data dashboard akan diperbarui setelah terhubung ke database."
        );
        isiInfo.setFont(new Font("SansSerif", Font.PLAIN, 12));
        isiInfo.setForeground(abu);

        infoTeks.add(judulInfo);
        infoTeks.add(Box.createVerticalStrut(6));
        infoTeks.add(isiInfo);

        catatan.add(ikonInfo, BorderLayout.WEST);
        catatan.add(infoTeks, BorderLayout.CENTER);

        isi.add(catatan);

        konten.add(isi, BorderLayout.NORTH);
        konten.revalidate();
        konten.repaint();
    }

    private JPanel buatKartu(
        String judul, String angka, String catatan,
        String ikon, Color aksen, Color latarIkon
    ) {
        JPanel kartu = panelPutih();
        kartu.setLayout(new BorderLayout(10, 7));
        kartu.setBorder(new CompoundBorder(
            new LineBorder(garis),
            new EmptyBorder(15, 15, 15, 15)
        ));

        JPanel bagianAtas = new JPanel(new BorderLayout());
        bagianAtas.setOpaque(false);

        JLabel nama = new JLabel(judul);
        nama.setFont(new Font("SansSerif", Font.BOLD, 10));
        nama.setForeground(abu);

        JLabel simbol = new JLabel(ikon);
        simbol.setFont(new Font("SansSerif", Font.BOLD, 20));
        simbol.setForeground(aksen);
        simbol.setHorizontalAlignment(SwingConstants.CENTER);
        simbol.setPreferredSize(new Dimension(38, 38));
        simbol.setOpaque(true);
        simbol.setBackground(latarIkon);

        bagianAtas.add(nama, BorderLayout.CENTER);
        bagianAtas.add(simbol, BorderLayout.EAST);

        JLabel nilai = new JLabel(angka);
        nilai.setFont(new Font("SansSerif", Font.BOLD, 30));
        nilai.setForeground(aksen);

        JLabel keterangan = new JLabel(catatan);
        keterangan.setFont(new Font("SansSerif", Font.PLAIN, 11));
        keterangan.setForeground(abu);

        kartu.add(bagianAtas, BorderLayout.NORTH);
        kartu.add(nilai, BorderLayout.CENTER);
        kartu.add(keterangan, BorderLayout.SOUTH);

        return kartu;
    }

    private JPanel buatPanelTabel() {
        JPanel panel = panelPutih();
        panel.setLayout(new BorderLayout(0, 14));
        panel.setBorder(new CompoundBorder(
            new LineBorder(garis),
            new EmptyBorder(17, 17, 17, 17)
        ));

        JLabel judul = new JLabel("Ringkasan Data Obat");
        judul.setFont(new Font("SansSerif", Font.BOLD, 15));
        judul.setForeground(teks);

        JLabel subjudul = new JLabel("Daftar persediaan terbaru");
        subjudul.setFont(new Font("SansSerif", Font.PLAIN, 11));
        subjudul.setForeground(abu);

        JPanel kepala = new JPanel();
        kepala.setOpaque(false);
        kepala.setLayout(new BoxLayout(kepala, BoxLayout.Y_AXIS));
        kepala.add(judul);
        kepala.add(Box.createVerticalStrut(5));
        kepala.add(subjudul);

        String[] kolom = {
            "Kode", "Nama Obat", "Stok", "Status"
        };

        DefaultTableModel model = new DefaultTableModel(
            new Object[][] {},
            kolom
        ) {
            @Override
            public boolean isCellEditable(int row, int col) {
                return false;
            }
        };

        tabelObat = new JTable(model);
        tabelObat.setFont(new Font("SansSerif", Font.PLAIN, 11));
        tabelObat.setRowHeight(35);
        tabelObat.setShowVerticalLines(false);
        tabelObat.setGridColor(garis);
        tabelObat.setSelectionBackground(
            new Color(241, 236, 255)
        );
        tabelObat.setSelectionForeground(teks);
        tabelObat.getTableHeader().setFont(
            new Font("SansSerif", Font.BOLD, 11)
        );
        tabelObat.getTableHeader().setBackground(
            new Color(249, 249, 253)
        );
        tabelObat.getTableHeader().setForeground(abu);
        tabelObat.getTableHeader().setPreferredSize(
            new Dimension(0, 36)
        );

        JScrollPane scroll = new JScrollPane(tabelObat);
        scroll.setBorder(new LineBorder(garis));

        JLabel kosong = new JLabel(
            "<html><div style='text-align:center;'>"
            + "<b>Belum ada data obat</b><br><br>"
            + "Tambahkan obat untuk melihat ringkasan di sini."
            + "</div></html>",
            SwingConstants.CENTER
        );
        kosong.setFont(new Font("SansSerif", Font.PLAIN, 12));
        kosong.setForeground(abu);

        JPanel isiTabel = new JPanel(new BorderLayout());
        isiTabel.add(scroll, BorderLayout.CENTER);
        isiTabel.add(kosong, BorderLayout.SOUTH);
        isiTabel.setBackground(Color.WHITE);

        panel.add(kepala, BorderLayout.NORTH);
        panel.add(isiTabel, BorderLayout.CENTER);

        return panel;
    }

    private JPanel buatPanelPeringatan() {
        JPanel panel = panelPutih();
        panel.setLayout(new BorderLayout(0, 15));
        panel.setBorder(new CompoundBorder(
            new LineBorder(garis),
            new EmptyBorder(17, 17, 17, 17)
        ));

        JLabel judul = new JLabel("Peringatan & Pengingat");
        judul.setFont(new Font("SansSerif", Font.BOLD, 15));
        judul.setForeground(teks);

        JLabel subjudul = new JLabel(
            "Pantau kondisi persediaan obat"
        );
        subjudul.setFont(new Font("SansSerif", Font.PLAIN, 11));
        subjudul.setForeground(abu);

        JPanel kepala = new JPanel();
        kepala.setOpaque(false);
        kepala.setLayout(new BoxLayout(kepala, BoxLayout.Y_AXIS));
        kepala.add(judul);
        kepala.add(Box.createVerticalStrut(5));
        kepala.add(subjudul);

        JPanel daftar = new JPanel();
        daftar.setOpaque(false);
        daftar.setLayout(new BoxLayout(
            daftar, BoxLayout.Y_AXIS
        ));

        daftar.add(buatPeringatan(
            "!", "Stok Menipis (ROB)",
            "Obat yang mencapai batas minimum",
            new Color(222, 153, 45),
            new Color(255, 247, 226)
        ));

        daftar.add(Box.createVerticalStrut(12));

        daftar.add(buatPeringatan(
            "◷", "Mendekati Kedaluwarsa",
            "Periksa tanggal kedaluwarsa batch",
            new Color(218, 91, 113),
            new Color(255, 237, 241)
        ));

        daftar.add(Box.createVerticalStrut(12));

        daftar.add(buatPeringatan(
            "✓", "Prioritas FEFO",
            "Dahulukan batch yang lebih cepat kedaluwarsa",
            ungu, new Color(243, 238, 255)
        ));

        JPanel info = new JPanel(new BorderLayout());
        info.setBackground(new Color(249, 249, 253));
        info.setBorder(new EmptyBorder(12, 12, 12, 12));

        JLabel pesan = new JLabel(
            "<html><b>Belum ada peringatan aktif</b><br>"
            + "<span style='color:#858B9E'>"
            + "Peringatan akan tampil berdasarkan data stok."
            + "</span></html>"
        );
        pesan.setFont(new Font("SansSerif", Font.PLAIN, 11));
        pesan.setForeground(teks);

        info.add(pesan, BorderLayout.CENTER);

        JPanel bawah = new JPanel(new BorderLayout(0, 12));
        bawah.setOpaque(false);
        bawah.add(daftar, BorderLayout.NORTH);
        bawah.add(info, BorderLayout.SOUTH);

        panel.add(kepala, BorderLayout.NORTH);
        panel.add(bawah, BorderLayout.CENTER);

        return panel;
    }

    private JPanel buatPeringatan(
        String ikon, String judul, String deskripsi,
        Color aksen, Color warnaLatar
    ) {
        JPanel item = new JPanel(new BorderLayout(12, 0));
        item.setOpaque(false);
        item.setBorder(new EmptyBorder(5, 0, 5, 0));

        JLabel simbol = new JLabel(ikon);
        simbol.setFont(new Font("SansSerif", Font.BOLD, 17));
        simbol.setForeground(aksen);
        simbol.setOpaque(true);
        simbol.setBackground(warnaLatar);
        simbol.setHorizontalAlignment(SwingConstants.CENTER);
        simbol.setPreferredSize(new Dimension(42, 42));

        JPanel keterangan = new JPanel();
        keterangan.setOpaque(false);
        keterangan.setLayout(new BoxLayout(
            keterangan, BoxLayout.Y_AXIS
        ));

        JLabel nama = new JLabel(judul);
        nama.setFont(new Font("SansSerif", Font.BOLD, 12));
        nama.setForeground(teks);

        JLabel detail = new JLabel(deskripsi);
        detail.setFont(new Font("SansSerif", Font.PLAIN, 10));
        detail.setForeground(abu);

        keterangan.add(nama);
        keterangan.add(Box.createVerticalStrut(5));
        keterangan.add(detail);

        item.add(simbol, BorderLayout.WEST);
        item.add(keterangan, BorderLayout.CENTER);

        return item;
    }

    private JPanel panelPutih() {
        JPanel panel = new JPanel();
        panel.setBackground(Color.WHITE);
        return panel;
    }

    private void tampilHalamanKosong(
        String judul, String deskripsi
    ) {
        judulHalaman.setText(judul);
        konten.removeAll();
        konten.setLayout(new BorderLayout());

        JPanel panel = panelPutih();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(new EmptyBorder(35, 35, 35, 35));

        JLabel nama = new JLabel(judul);
        nama.setFont(new Font("SansSerif", Font.BOLD, 24));
        nama.setForeground(teks);
        nama.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel keterangan = new JLabel(deskripsi);
        keterangan.setFont(new Font("SansSerif", Font.PLAIN, 13));
        keterangan.setForeground(abu);
        keterangan.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel status = new JLabel(
            "<html><br><b>Halaman siap dikembangkan</b><br><br>"
            + "Fitur ini akan dihubungkan ke database HAI OBAT "
            + "pada tahap berikutnya.</html>"
        );
        status.setFont(new Font("SansSerif", Font.PLAIN, 13));
        status.setForeground(teks);
        status.setAlignmentX(Component.LEFT_ALIGNMENT);

        panel.add(nama);
        panel.add(Box.createVerticalStrut(10));
        panel.add(keterangan);
        panel.add(Box.createVerticalStrut(25));
        panel.add(status);

        konten.add(panel, BorderLayout.CENTER);
        konten.revalidate();
        konten.repaint();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new dashboard().setVisible(true);
        });
    }
}
