
package aplikasi.pendataan.obat;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.geom.*;

public class login extends JFrame {

    private JTextField txtUsername;
    private JPasswordField txtPassword;
    private JCheckBox chkTampilkan;

    private final Color UNGU = new Color(139, 105, 210);
    private final Color UNGU_GELAP = new Color(105, 76, 170);
    private final Color TEKS = new Color(55, 55, 65);
    private final Color ABU = new Color(145, 145, 155);

    public login() {
        initUI();
    }

    private void initUI() {
        setTitle("HAI OBAT | Sistem Pendataan Obat");
        setSize(1100, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel root = new JPanel(new GridBagLayout());
        root.setBackground(new Color(246, 245, 250));

        JPanel card = new JPanel(new GridLayout(1, 2));
        card.setPreferredSize(new Dimension(900, 500));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createLineBorder(
                new Color(230, 228, 238)));

        // PANEL KIRI
        JPanel panelVisual = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);

                Graphics2D g2 = (Graphics2D) g.create();
                int w = getWidth();
                int h = getHeight();

                g2.setRenderingHint(
                        RenderingHints.KEY_ANTIALIASING,
                        RenderingHints.VALUE_ANTIALIAS_ON);

                g2.setPaint(new GradientPaint(
                        0, 0, new Color(119, 94, 195),
                        w, h, new Color(222, 154, 224)));

                g2.fillRect(0, 0, w, h);

                // Lingkaran dekoratif
                g2.setColor(new Color(255, 255, 255, 28));
                g2.fillOval(w - 180, 50, 230, 230);
                g2.fillOval(-100, h - 180, 250, 250);

                // Logo heksagon
                Polygon hex = new Polygon();
                for (int i = 0; i < 6; i++) {
                    double a = Math.toRadians(i * 60 - 30);
                    hex.addPoint(
                            45 + (int) (17 * Math.cos(a)),
                            45 + (int) (17 * Math.sin(a)));
                }

                g2.setColor(Color.WHITE);
                g2.fillPolygon(hex);

                Polygon inner = new Polygon();
                for (int i = 0; i < 6; i++) {
                    double a = Math.toRadians(i * 60 - 30);
                    inner.addPoint(
                            45 + (int) (8 * Math.cos(a)),
                            45 + (int) (8 * Math.sin(a)));
                }

                g2.setColor(UNGU);
                g2.fillPolygon(inner);

                // Ilustrasi kapsul
                Graphics2D pill = (Graphics2D) g2.create();
                pill.translate(w / 2.0, h / 2.0 - 10);
                pill.rotate(-Math.PI / 5);

                pill.setColor(new Color(255, 255, 255, 230));
                pill.fill(new RoundRectangle2D.Double(
                        -75, -29, 150, 58, 58, 58));

                pill.setClip(new RoundRectangle2D.Double(
                        -75, -29, 150, 58, 58, 58));

                pill.setColor(new Color(255, 207, 226));
                pill.fillRect(-2, -30, 80, 60);

                pill.setColor(new Color(255, 255, 255, 170));
                pill.setStroke(new BasicStroke(2));
                pill.drawLine(0, -27, 0, 27);
                pill.dispose();

                // Teks panel kiri
                g2.setColor(Color.WHITE);
                g2.setFont(new Font("SansSerif", Font.BOLD, 27));
                g2.drawString("HAI OBAT", 35, h - 95);

                g2.setFont(new Font("SansSerif", Font.PLAIN, 14));
                g2.drawString("Sistem Informasi Pendataan Obat",
                        35, h - 65);
                g2.drawString("Kelola stok dengan lebih mudah dan teratur.",
                        35, h - 42);

                g2.dispose();
            }
        };
        panelVisual.setPreferredSize(new Dimension(390, 500));
        card.add(panelVisual);

        // PANEL KANAN
        JPanel form = new JPanel(null);
        form.setBackground(Color.WHITE);
        form.setPreferredSize(new Dimension(510, 500));

        JLabel judul = new JLabel("Selamat Datang");
        judul.setFont(new Font("SansSerif", Font.BOLD, 28));
        judul.setForeground(TEKS);
        judul.setBounds(45, 65, 400, 40);
        form.add(judul);

        JLabel deskripsi = new JLabel(
                "Silakan masuk ke akun HAI OBAT Anda.");
        deskripsi.setFont(new Font("SansSerif", Font.PLAIN, 14));
        deskripsi.setForeground(ABU);
        deskripsi.setBounds(45, 108, 400, 25);
        form.add(deskripsi);

        JLabel labelUsername = new JLabel("Username");
        labelUsername.setFont(
                new Font("SansSerif", Font.BOLD, 13));
        labelUsername.setForeground(TEKS);
        labelUsername.setBounds(45, 165, 400, 22);
        form.add(labelUsername);

        txtUsername = new JTextField();
        txtUsername.setFont(new Font("SansSerif", Font.PLAIN, 15));
        txtUsername.setForeground(TEKS);
        txtUsername.setBackground(new Color(250, 249, 253));
        txtUsername.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(
                        new Color(226, 222, 237)),
                new EmptyBorder(8, 12, 8, 12)));
        txtUsername.setBounds(45, 190, 400, 44);
        txtUsername.setToolTipText("Masukkan username");
        form.add(txtUsername);

        JLabel labelPassword = new JLabel("Password");
        labelPassword.setFont(
                new Font("SansSerif", Font.BOLD, 13));
        labelPassword.setForeground(TEKS);
        labelPassword.setBounds(45, 250, 400, 22);
        form.add(labelPassword);

        txtPassword = new JPasswordField();
        txtPassword.setFont(new Font("SansSerif", Font.PLAIN, 15));
        txtPassword.setForeground(TEKS);
        txtPassword.setBackground(new Color(250, 249, 253));
        txtPassword.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(
                        new Color(226, 222, 237)),
                new EmptyBorder(8, 12, 8, 12)));
        txtPassword.setBounds(45, 275, 400, 44);
        txtPassword.setToolTipText("Masukkan password");
        form.add(txtPassword);

        chkTampilkan = new JCheckBox("Tampilkan password");
        chkTampilkan.setFont(
                new Font("SansSerif", Font.PLAIN, 12));
        chkTampilkan.setForeground(ABU);
        chkTampilkan.setOpaque(false);
        chkTampilkan.setFocusPainted(false);
        chkTampilkan.setBounds(45, 327, 200, 25);

        chkTampilkan.addActionListener(e -> {
            if (chkTampilkan.isSelected()) {
                txtPassword.setEchoChar((char) 0);
            } else {
                txtPassword.setEchoChar('\u2022');
            }
        });
        form.add(chkTampilkan);

        JButton btnLogin = new JButton("MASUK");
        btnLogin.setFont(new Font("SansSerif", Font.BOLD, 14));
        btnLogin.setForeground(Color.WHITE);
        btnLogin.setBackground(UNGU);
        btnLogin.setOpaque(true);
        btnLogin.setBorderPainted(false);
        btnLogin.setFocusPainted(false);
        btnLogin.setCursor(
                Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnLogin.setBounds(45, 370, 400, 48);

        btnLogin.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent e) {
                btnLogin.setBackground(UNGU_GELAP);
            }

            @Override
            public void mouseExited(java.awt.event.MouseEvent e) {
                btnLogin.setBackground(UNGU);
            }
        });

        btnLogin.addActionListener(e -> prosesLogin());
        form.add(btnLogin);

        JLabel footer = new JLabel(
                "© 2026 HAI OBAT | ROB & FEFO");
        footer.setFont(new Font("SansSerif", Font.PLAIN, 11));
        footer.setForeground(ABU);
        footer.setBounds(45, 445, 400, 20);
        form.add(footer);

        card.add(form);
        root.add(card);
        setContentPane(root);
        getRootPane().setDefaultButton(btnLogin);
    }



private void prosesLogin() {
    String username = txtUsername.getText().trim();
    String password = new String(txtPassword.getPassword());

    if (username.isEmpty() || password.isEmpty()) {
        JOptionPane.showMessageDialog(
                this,
                "Username dan password wajib diisi!",
                "Peringatan",
                JOptionPane.WARNING_MESSAGE
        );
        return;
    }

    String sql = "SELECT username, nama_lengkap, role "
               + "FROM users "
               + "WHERE username = ? AND password = ?";

    try (
        Connection conn = koneksi.getKoneksi();
        PreparedStatement ps = conn.prepareStatement(sql)
    ) {
        ps.setString(1, username);
        ps.setString(2, password);

        try (ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                String nama = rs.getString("nama_lengkap");

                JOptionPane.showMessageDialog(
                        this,
                        "Selamat datang, " + nama + "!"
                );

                dashboard halamanDashboard = new dashboard();
                halamanDashboard.setVisible(true);
                dispose();

            } else {
                JOptionPane.showMessageDialog(
                        this,
                        "Username atau password salah!",
                        "Login Gagal",
                        JOptionPane.ERROR_MESSAGE
                );

                txtPassword.setText("");
                txtPassword.requestFocusInWindow();
            }
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(
                this,
                "Gagal mengakses database!\n" + e.getMessage(),
                "Kesalahan Database",
                JOptionPane.ERROR_MESSAGE
        );
    }
}


    // MAIN METHOD
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                login form = new login();
                form.setVisible(true);
                form.toFront();
                form.requestFocus();
            }
        });
    }
}
